import java.util.Scanner;
public class GameOfNim{
	Scanner sc=new Scanner(System.in);
	int player;
	int player01=1;
	int player02=2;
	int currentPlayer;
	String NumberOfSticks;
	int NumberOfSticksInt;
	String player1;
	String player2;
	String p1;
	String p2;
	String firstPlayer;
	String secondPlayer;
	String totalStick;
	int totalStickInt;
	String stickValue;
	int stickValueInt;

	public static void main(String[] args) {
		System.out.println("\t+Game of Nim+");
		System.out.println("\t-------------");
		GameOfNim gon=new GameOfNim();
		gon.firstPlayer();
		gon.howManySticks();
		gon.play();
	}
	public void firstPlayer(){
			System.out.println();
			System.out.print("Enter the name of player 1:");
			player1=sc.next();
			System.out.print("Enter the name of player 2:");
			player2=sc.next();
			System.out.println();
			System.out.println(player1+" You can start the game:");
			System.out.println("--------------------------------------------");
			while(true){
				System.out.print(player1+" You can decide who can start the game first(enter the name):");
				firstPlayer=sc.next();
				if(firstPlayer.equals(player1) || firstPlayer.equals(player2) ){
					//System.out.print("Correct");
					break;
				}else{
					System.out.println("|-----Please enter correct name("+ player1+" or "+player2+")-----|");
				}
			}
	}//end of FirstPalyer()
	public void howManySticks(){
		if(firstPlayer.equals(player1)){
				while(true){
					System.out.print(player2+" You can decide, How many sticks can we use to the game(20-30):");
					NumberOfSticks=sc.next();
					try{
						NumberOfSticksInt=Integer.parseInt(NumberOfSticks);  
						if(NumberOfSticksInt<=30 && NumberOfSticksInt>=20){
							break;
						}else{
							System.out.println("|-----Please enter correct value(20-30)-----|");
						}
					}catch(Exception e){
						System.out.println("|-----Please enter correct Integer value(20-30)-----|");
					}
					
				}
			}else{
				while(true){
					System.out.print(player1+" You can decide, How many sticks can we use to the game(20-30):");
					NumberOfSticks=sc.next();
					try{
						NumberOfSticksInt=Integer.parseInt(NumberOfSticks);  
						if(NumberOfSticksInt<=30 && NumberOfSticksInt>=20){
							break;
						}else{
							System.out.println("|-----Please enter correct value(20-30)-----|");
						}
					}catch(Exception e){
						System.out.println("|-----Please enter correct Integer value(20-30)-----|");
					}
					
				}
			}//end of if
	}//end of HowManySticks()
	public void play(){
		System.out.println();
		System.out.println("|---------------------Game Details------------------------------|");
		System.out.println("|                                                               |");
		System.out.println("|Players\t\t:"+player1+" and "+player2+"\t\t\t|");
		System.out.println("|First Player\t\t:"+firstPlayer+"\t\t\t\t\t|");
		System.out.println("|Number of stick\t:"+NumberOfSticks+"\t\t\t\t\t|");
		System.out.println("|                                                               |");
		System.out.println("|---------------------Let's Play--------------------------------|");
		System.out.print("Sticks-->"+NumberOfSticksInt+":");
		for(int i=1;i<=NumberOfSticksInt;i++){
			System.out.print(" | ");
		}
		System.out.println();
		System.out.print("|-------------Please get 1-3 stick only-----------------|");
		System.out.println();
		totalStickInt=NumberOfSticksInt;
		if(firstPlayer.equals(player1)){
			currentPlayer=0;
			secondPlayer=player2;
		}else{
			currentPlayer=1;
			secondPlayer=player1;
		}
		while(totalStickInt>=1){
			while(true){
				try{
					System.out.println();
					System.out.println();
					
					if(currentPlayer==0){
						System.out.print(firstPlayer+" Plese enter the value of stick do you want(1-3):");
						stickValue=sc.next();
						stickValueInt=Integer.parseInt(stickValue);
						if(stickValueInt>=1 && stickValueInt<=3){
							System.out.println(stickValueInt);
							currentPlayer=currentPlayer+1;
							break;
						}else{
							System.out.println("|------Please enter the Correct Value(1-3)--------|");
						}
						
					}else{
						System.out.print(secondPlayer+" Plese enter the value of stick do you want(1-3):");
						stickValue=sc.next();
						stickValueInt=Integer.parseInt(stickValue);
						if(stickValueInt>=1 && stickValueInt<=3){
							System.out.println(stickValueInt);
							currentPlayer=currentPlayer-1;
							break;
						}else{
							System.out.println("|------Please enter the Correct Value(1-3)--------|");
						}
						
					}
					
				}catch(Exception e){
					System.out.println("|------Please enter the Correct Integer Value(1-3)--------|");
				}
			}
			totalStickInt=totalStickInt-stickValueInt;
			System.out.println();
			System.out.print("Sticks left-->"+totalStickInt+":");
			for(int i=1;i<=totalStickInt;i++){
				System.out.print(" | ");
			}

		}
		



	}
}